
1. extract the .rar file in a folder of your choice
2.after extracting, in the same folder where src is located run npm install 

then please install the following:

npm i --save @fortawesome/fontawesome-svg-core
  npm install --save @fortawesome/free-solid-svg-icons
  npm install --save @fortawesome/react-fontawesome

  then to start run npm start