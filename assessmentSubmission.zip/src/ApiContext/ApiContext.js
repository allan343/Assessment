import React from 'react';

export default React.createContext({
  //context methods

  tagsToFilter: [],

  addTagsToFilter: () => { },
  getTagsToFilter: () => { },
  getTagsToRender: () => { },

})